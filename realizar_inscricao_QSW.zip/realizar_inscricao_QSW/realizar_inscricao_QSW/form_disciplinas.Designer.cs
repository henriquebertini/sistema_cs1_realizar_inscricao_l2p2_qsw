﻿namespace realizar_inscricao_QSW
{
    partial class form_disciplinas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnValidarInscricao = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cbMetodologiasTurma1 = new System.Windows.Forms.CheckBox();
            this.cbMetodologiasTurma2 = new System.Windows.Forms.CheckBox();
            this.cbMetodologiasTurma3 = new System.Windows.Forms.CheckBox();
            this.cbGestaoProjetosTurma1 = new System.Windows.Forms.CheckBox();
            this.cbGestaoProjetosTurma2 = new System.Windows.Forms.CheckBox();
            this.cbServicosRedesTurma1 = new System.Windows.Forms.CheckBox();
            this.cbServicosRedesTurma2 = new System.Windows.Forms.CheckBox();
            this.cbServicosRedesTurma3 = new System.Windows.Forms.CheckBox();
            this.cbPS1Turma1 = new System.Windows.Forms.CheckBox();
            this.cbPS1Turma2 = new System.Windows.Forms.CheckBox();
            this.cbWEBTurma1 = new System.Windows.Forms.CheckBox();
            this.cbWEBTurma2 = new System.Windows.Forms.CheckBox();
            this.cbQSWTurma1 = new System.Windows.Forms.CheckBox();
            this.cbQSWTurma2 = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnVisualizarDadosDasTurmas = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(348, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(476, 52);
            this.label1.TabIndex = 0;
            this.label1.Text = "Disciplinas disponíveis";
            // 
            // btnValidarInscricao
            // 
            this.btnValidarInscricao.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnValidarInscricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnValidarInscricao.ForeColor = System.Drawing.Color.White;
            this.btnValidarInscricao.Location = new System.Drawing.Point(53, 670);
            this.btnValidarInscricao.Name = "btnValidarInscricao";
            this.btnValidarInscricao.Size = new System.Drawing.Size(314, 47);
            this.btnValidarInscricao.TabIndex = 14;
            this.btnValidarInscricao.Text = "Validar inscrição";
            this.btnValidarInscricao.UseVisualStyleBackColor = false;
            this.btnValidarInscricao.Click += new System.EventHandler(this.btnValidarInscricao_Click);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.MidnightBlue;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(18, 364);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(319, 35);
            this.label5.TabIndex = 5;
            this.label5.Text = "Serviços de Rede";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.MidnightBlue;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(18, 489);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(319, 35);
            this.label7.TabIndex = 7;
            this.label7.Text = "Qualidade de Software";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.MidnightBlue;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(27, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(319, 35);
            this.label2.TabIndex = 2;
            this.label2.Text = "METODOLOGIAS ÁGEIS";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.MidnightBlue;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(27, 269);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(319, 35);
            this.label6.TabIndex = 6;
            this.label6.Text = "Desenvolvimento Web";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.MidnightBlue;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(27, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(319, 35);
            this.label4.TabIndex = 4;
            this.label4.Text = "Gestão de Projetos";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.MidnightBlue;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(382, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(319, 35);
            this.label3.TabIndex = 3;
            this.label3.Text = "Projeto de Sistemas I";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbMetodologiasTurma1
            // 
            this.cbMetodologiasTurma1.AutoSize = true;
            this.cbMetodologiasTurma1.BackColor = System.Drawing.Color.LightGray;
            this.cbMetodologiasTurma1.Location = new System.Drawing.Point(33, 66);
            this.cbMetodologiasTurma1.Name = "cbMetodologiasTurma1";
            this.cbMetodologiasTurma1.Size = new System.Drawing.Size(93, 24);
            this.cbMetodologiasTurma1.TabIndex = 19;
            this.cbMetodologiasTurma1.Text = "Turma 1";
            this.cbMetodologiasTurma1.UseVisualStyleBackColor = false;
            this.cbMetodologiasTurma1.CheckedChanged += new System.EventHandler(this.cbMetodologiasTurma1_CheckedChanged);
            // 
            // cbMetodologiasTurma2
            // 
            this.cbMetodologiasTurma2.AutoSize = true;
            this.cbMetodologiasTurma2.BackColor = System.Drawing.Color.LightGray;
            this.cbMetodologiasTurma2.Location = new System.Drawing.Point(33, 96);
            this.cbMetodologiasTurma2.Name = "cbMetodologiasTurma2";
            this.cbMetodologiasTurma2.Size = new System.Drawing.Size(93, 24);
            this.cbMetodologiasTurma2.TabIndex = 20;
            this.cbMetodologiasTurma2.Text = "Turma 2";
            this.cbMetodologiasTurma2.UseVisualStyleBackColor = false;
            this.cbMetodologiasTurma2.CheckedChanged += new System.EventHandler(this.cbMetodologiasTurma2_CheckedChanged);
            // 
            // cbMetodologiasTurma3
            // 
            this.cbMetodologiasTurma3.AutoSize = true;
            this.cbMetodologiasTurma3.BackColor = System.Drawing.Color.LightGray;
            this.cbMetodologiasTurma3.Location = new System.Drawing.Point(33, 126);
            this.cbMetodologiasTurma3.Name = "cbMetodologiasTurma3";
            this.cbMetodologiasTurma3.Size = new System.Drawing.Size(93, 24);
            this.cbMetodologiasTurma3.TabIndex = 21;
            this.cbMetodologiasTurma3.Text = "Turma 3";
            this.cbMetodologiasTurma3.UseVisualStyleBackColor = false;
            this.cbMetodologiasTurma3.CheckedChanged += new System.EventHandler(this.cbMetodologiasTurma3_CheckedChanged);
            // 
            // cbGestaoProjetosTurma1
            // 
            this.cbGestaoProjetosTurma1.AutoSize = true;
            this.cbGestaoProjetosTurma1.BackColor = System.Drawing.Color.LightGray;
            this.cbGestaoProjetosTurma1.Location = new System.Drawing.Point(33, 203);
            this.cbGestaoProjetosTurma1.Name = "cbGestaoProjetosTurma1";
            this.cbGestaoProjetosTurma1.Size = new System.Drawing.Size(93, 24);
            this.cbGestaoProjetosTurma1.TabIndex = 27;
            this.cbGestaoProjetosTurma1.Text = "Turma 1";
            this.cbGestaoProjetosTurma1.UseVisualStyleBackColor = false;
            this.cbGestaoProjetosTurma1.CheckedChanged += new System.EventHandler(this.cbGestaoProjetosTurma1_CheckedChanged);
            // 
            // cbGestaoProjetosTurma2
            // 
            this.cbGestaoProjetosTurma2.AutoSize = true;
            this.cbGestaoProjetosTurma2.BackColor = System.Drawing.Color.LightGray;
            this.cbGestaoProjetosTurma2.Location = new System.Drawing.Point(33, 233);
            this.cbGestaoProjetosTurma2.Name = "cbGestaoProjetosTurma2";
            this.cbGestaoProjetosTurma2.Size = new System.Drawing.Size(93, 24);
            this.cbGestaoProjetosTurma2.TabIndex = 28;
            this.cbGestaoProjetosTurma2.Text = "Turma 2";
            this.cbGestaoProjetosTurma2.UseVisualStyleBackColor = false;
            this.cbGestaoProjetosTurma2.CheckedChanged += new System.EventHandler(this.cbGestaoProjetosTurma2_CheckedChanged);
            // 
            // cbServicosRedesTurma1
            // 
            this.cbServicosRedesTurma1.AutoSize = true;
            this.cbServicosRedesTurma1.BackColor = System.Drawing.Color.LightGray;
            this.cbServicosRedesTurma1.Location = new System.Drawing.Point(24, 402);
            this.cbServicosRedesTurma1.Name = "cbServicosRedesTurma1";
            this.cbServicosRedesTurma1.Size = new System.Drawing.Size(93, 24);
            this.cbServicosRedesTurma1.TabIndex = 33;
            this.cbServicosRedesTurma1.Text = "Turma 1";
            this.cbServicosRedesTurma1.UseVisualStyleBackColor = false;
            this.cbServicosRedesTurma1.CheckedChanged += new System.EventHandler(this.cbServicosRedesTurma1_CheckedChanged);
            // 
            // cbServicosRedesTurma2
            // 
            this.cbServicosRedesTurma2.AutoSize = true;
            this.cbServicosRedesTurma2.BackColor = System.Drawing.Color.LightGray;
            this.cbServicosRedesTurma2.Location = new System.Drawing.Point(24, 432);
            this.cbServicosRedesTurma2.Name = "cbServicosRedesTurma2";
            this.cbServicosRedesTurma2.Size = new System.Drawing.Size(93, 24);
            this.cbServicosRedesTurma2.TabIndex = 34;
            this.cbServicosRedesTurma2.Text = "Turma 2";
            this.cbServicosRedesTurma2.UseVisualStyleBackColor = false;
            this.cbServicosRedesTurma2.CheckedChanged += new System.EventHandler(this.cbServicosRedesTurma2_CheckedChanged);
            // 
            // cbServicosRedesTurma3
            // 
            this.cbServicosRedesTurma3.AutoSize = true;
            this.cbServicosRedesTurma3.BackColor = System.Drawing.Color.LightGray;
            this.cbServicosRedesTurma3.Location = new System.Drawing.Point(24, 462);
            this.cbServicosRedesTurma3.Name = "cbServicosRedesTurma3";
            this.cbServicosRedesTurma3.Size = new System.Drawing.Size(93, 24);
            this.cbServicosRedesTurma3.TabIndex = 35;
            this.cbServicosRedesTurma3.Text = "Turma 3";
            this.cbServicosRedesTurma3.UseVisualStyleBackColor = false;
            this.cbServicosRedesTurma3.CheckedChanged += new System.EventHandler(this.cbServicosRedesTurma3_CheckedChanged);
            // 
            // cbPS1Turma1
            // 
            this.cbPS1Turma1.AutoSize = true;
            this.cbPS1Turma1.BackColor = System.Drawing.Color.LightGray;
            this.cbPS1Turma1.Location = new System.Drawing.Point(387, 68);
            this.cbPS1Turma1.Name = "cbPS1Turma1";
            this.cbPS1Turma1.Size = new System.Drawing.Size(93, 24);
            this.cbPS1Turma1.TabIndex = 36;
            this.cbPS1Turma1.Text = "Turma 1";
            this.cbPS1Turma1.UseVisualStyleBackColor = false;
            this.cbPS1Turma1.CheckedChanged += new System.EventHandler(this.cbPS1Turma1_CheckedChanged);
            // 
            // cbPS1Turma2
            // 
            this.cbPS1Turma2.AutoSize = true;
            this.cbPS1Turma2.BackColor = System.Drawing.Color.LightGray;
            this.cbPS1Turma2.Location = new System.Drawing.Point(387, 98);
            this.cbPS1Turma2.Name = "cbPS1Turma2";
            this.cbPS1Turma2.Size = new System.Drawing.Size(93, 24);
            this.cbPS1Turma2.TabIndex = 37;
            this.cbPS1Turma2.Text = "Turma 2";
            this.cbPS1Turma2.UseVisualStyleBackColor = false;
            this.cbPS1Turma2.CheckedChanged += new System.EventHandler(this.cbPS1Turma2_CheckedChanged);
            // 
            // cbWEBTurma1
            // 
            this.cbWEBTurma1.AutoSize = true;
            this.cbWEBTurma1.BackColor = System.Drawing.Color.LightGray;
            this.cbWEBTurma1.Location = new System.Drawing.Point(33, 307);
            this.cbWEBTurma1.Name = "cbWEBTurma1";
            this.cbWEBTurma1.Size = new System.Drawing.Size(93, 24);
            this.cbWEBTurma1.TabIndex = 38;
            this.cbWEBTurma1.Text = "Turma 1";
            this.cbWEBTurma1.UseVisualStyleBackColor = false;
            this.cbWEBTurma1.CheckedChanged += new System.EventHandler(this.cbWEBTurma1_CheckedChanged);
            // 
            // cbWEBTurma2
            // 
            this.cbWEBTurma2.AutoSize = true;
            this.cbWEBTurma2.BackColor = System.Drawing.Color.LightGray;
            this.cbWEBTurma2.Location = new System.Drawing.Point(33, 337);
            this.cbWEBTurma2.Name = "cbWEBTurma2";
            this.cbWEBTurma2.Size = new System.Drawing.Size(93, 24);
            this.cbWEBTurma2.TabIndex = 39;
            this.cbWEBTurma2.Text = "Turma 2";
            this.cbWEBTurma2.UseVisualStyleBackColor = false;
            this.cbWEBTurma2.CheckedChanged += new System.EventHandler(this.cbWEBTurma2_CheckedChanged);
            // 
            // cbQSWTurma1
            // 
            this.cbQSWTurma1.AutoSize = true;
            this.cbQSWTurma1.BackColor = System.Drawing.Color.LightGray;
            this.cbQSWTurma1.Location = new System.Drawing.Point(24, 527);
            this.cbQSWTurma1.Name = "cbQSWTurma1";
            this.cbQSWTurma1.Size = new System.Drawing.Size(93, 24);
            this.cbQSWTurma1.TabIndex = 40;
            this.cbQSWTurma1.Text = "Turma 1";
            this.cbQSWTurma1.UseVisualStyleBackColor = false;
            this.cbQSWTurma1.CheckedChanged += new System.EventHandler(this.cbQSWTurma1_CheckedChanged);
            // 
            // cbQSWTurma2
            // 
            this.cbQSWTurma2.AutoSize = true;
            this.cbQSWTurma2.BackColor = System.Drawing.Color.LightGray;
            this.cbQSWTurma2.Location = new System.Drawing.Point(24, 557);
            this.cbQSWTurma2.Name = "cbQSWTurma2";
            this.cbQSWTurma2.Size = new System.Drawing.Size(93, 24);
            this.cbQSWTurma2.TabIndex = 41;
            this.cbQSWTurma2.Text = "Turma 2";
            this.cbQSWTurma2.UseVisualStyleBackColor = false;
            this.cbQSWTurma2.CheckedChanged += new System.EventHandler(this.cbQSWTurma2_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightGray;
            this.panel1.Controls.Add(this.btnVisualizarDadosDasTurmas);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.richTextBox1);
            this.panel1.Controls.Add(this.cbQSWTurma2);
            this.panel1.Controls.Add(this.cbQSWTurma1);
            this.panel1.Controls.Add(this.cbWEBTurma2);
            this.panel1.Controls.Add(this.cbWEBTurma1);
            this.panel1.Controls.Add(this.cbPS1Turma2);
            this.panel1.Controls.Add(this.cbPS1Turma1);
            this.panel1.Controls.Add(this.cbServicosRedesTurma3);
            this.panel1.Controls.Add(this.cbServicosRedesTurma2);
            this.panel1.Controls.Add(this.cbServicosRedesTurma1);
            this.panel1.Controls.Add(this.cbGestaoProjetosTurma2);
            this.panel1.Controls.Add(this.cbGestaoProjetosTurma1);
            this.panel1.Controls.Add(this.cbMetodologiasTurma3);
            this.panel1.Controls.Add(this.cbMetodologiasTurma2);
            this.panel1.Controls.Add(this.cbMetodologiasTurma1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(21, 64);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1134, 602);
            this.panel1.TabIndex = 15;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(387, 165);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(734, 416);
            this.richTextBox1.TabIndex = 42;
            this.richTextBox1.Text = "";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.MidnightBlue;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(387, 126);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(734, 36);
            this.label8.TabIndex = 43;
            this.label8.Text = "Resumo da inscrição";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkGreen;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(670, 670);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(314, 47);
            this.button1.TabIndex = 16;
            this.button1.Text = "Confirmar inscrição";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnVisualizarDadosDasTurmas
            // 
            this.btnVisualizarDadosDasTurmas.BackColor = System.Drawing.Color.SlateGray;
            this.btnVisualizarDadosDasTurmas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVisualizarDadosDasTurmas.ForeColor = System.Drawing.Color.White;
            this.btnVisualizarDadosDasTurmas.Location = new System.Drawing.Point(891, 16);
            this.btnVisualizarDadosDasTurmas.Name = "btnVisualizarDadosDasTurmas";
            this.btnVisualizarDadosDasTurmas.Size = new System.Drawing.Size(220, 100);
            this.btnVisualizarDadosDasTurmas.TabIndex = 44;
            this.btnVisualizarDadosDasTurmas.Text = "Visualizar dados das turmas";
            this.btnVisualizarDadosDasTurmas.UseVisualStyleBackColor = false;
            this.btnVisualizarDadosDasTurmas.Click += new System.EventHandler(this.btnVisualizarDadosDasTurmas_Click);
            // 
            // form_disciplinas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(1167, 729);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnValidarInscricao);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "form_disciplinas";
            this.Text = "form_disciplinas";
            this.Load += new System.EventHandler(this.form_disciplinas_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnValidarInscricao;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox cbMetodologiasTurma1;
        private System.Windows.Forms.CheckBox cbMetodologiasTurma2;
        private System.Windows.Forms.CheckBox cbMetodologiasTurma3;
        private System.Windows.Forms.CheckBox cbGestaoProjetosTurma1;
        private System.Windows.Forms.CheckBox cbGestaoProjetosTurma2;
        private System.Windows.Forms.CheckBox cbServicosRedesTurma1;
        private System.Windows.Forms.CheckBox cbServicosRedesTurma2;
        private System.Windows.Forms.CheckBox cbServicosRedesTurma3;
        private System.Windows.Forms.CheckBox cbPS1Turma1;
        private System.Windows.Forms.CheckBox cbPS1Turma2;
        private System.Windows.Forms.CheckBox cbWEBTurma1;
        private System.Windows.Forms.CheckBox cbWEBTurma2;
        private System.Windows.Forms.CheckBox cbQSWTurma1;
        private System.Windows.Forms.CheckBox cbQSWTurma2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnVisualizarDadosDasTurmas;
    }
}